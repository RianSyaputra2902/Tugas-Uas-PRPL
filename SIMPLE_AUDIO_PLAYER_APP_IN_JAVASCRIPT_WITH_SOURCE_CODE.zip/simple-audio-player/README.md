# simple-audio-player
A basic custom audio player built for as part of a UI component for a project
